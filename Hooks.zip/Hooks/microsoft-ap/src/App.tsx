import React from 'react';
import Counter from './Components/Counter/Counter';
import ClassState from './Components/ClassState/ClassState';
import FunctionState from './Containers/FunctionState/FunctionState';

const App = () => {
  return (
      <div>
        <Counter text="chicken" />
        <ClassState/>
        <FunctionState/>
      </div>
  );
};

export default App;