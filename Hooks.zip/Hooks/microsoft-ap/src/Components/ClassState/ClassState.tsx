import React, { Component } from 'react'
import { Input } from 'antd';

interface customState {
    name: string,
    surName: string,
    width:number
}
export class ClassState extends Component<{}, customState> {

    constructor(props: any) {
        super(props);
        this.state = {
            name: "Karthika",
            surName: "Rajaratna",
            width:window.innerWidth
        }
    }
    componentWillMount() { // when mounting the class
        document.title = this.state.name + ' ' + this.state.surName;
        window.addEventListener('resize',this.handleReSize);
    }
    componentWillUpdate(){ //during the manipulation in the class
        document.title=this.state.name+ ' '+this.state.surName;
    }

    handleReSize=()=> {
        this.setState({
           width:window.innerWidth
        });
     }
    
     componentWillUnmount(){
         window.removeEventListener('resize',this.handleReSize);
     }
    
    onNameChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
            this.setState({
                name: e.target.value
            });
        }
    onSurNameChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
            this.setState({
                surName: e.target.value
            });
        }
 

    render() {
        const { name, surName,width } = this.state;
        return (
            <>
                <h1>ClassState</h1>
                <Input size="small" value={name} onChange={this.onNameChange} />
                <Input size="small" value={surName} onChange={this.onSurNameChange} />
                <p>{name} {surName} </p>
                <h2>Width using componentWillMount and componentWillUnmount: {width}</h2>
            </>
        );
    }
}

export default ClassState
