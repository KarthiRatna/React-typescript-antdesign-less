import React from "react";
import  ButtonUtility  from '../../Containers/Button/ButtonUtility';
import { Typography } from 'antd';

const { Title } = Typography;

interface CustomInputProps {
    text: string;
}

interface CustomInputState {
    clicks: number;
}


class Counter extends React.Component<CustomInputProps, CustomInputState> {
    constructor(props: any) {
        super(props);
        this.state = { clicks: 0 };
    }
    render() {
        const _onButtonClick = () => {
            this.setState({
                clicks: clicks + 1
            });
        };
        const { text } = this.props;
        const { clicks } = this.state;
        return (
            <>
                <Title>{text}:{clicks}</Title>
                <hr/>
                <ButtonUtility button_text="Counter" onClick={_onButtonClick}/>
            </>
        );
    }
}

export default Counter;
