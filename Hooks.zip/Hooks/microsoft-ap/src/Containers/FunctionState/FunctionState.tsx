import React, { useState, useEffect } from 'react'
import { Input } from 'antd';

const FunctionState = () => {

    const name = useFormInput("Karthika");
    const surName = useFormInput("Rajaratna");
    const width = useWindowWidth();
    UsedocumentTitle(name.value + ' '+surName.value);
    return (
        <>
            <h1>Function State (use state, use Effect)</h1>
            <Input {...name} />
            <Input {...surName} />
            <p>{name.value} {surName.value} </p>
            <h2>Width using useEffect: {width}</h2>
        </>
    )
}
export default FunctionState;

function useFormInput(input: string) {
    const [value, setValue] = useState(input);
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        setValue(e.target.value);
    }
    return {
        value,
        onChange: handleChange
    }
}

function UsedocumentTitle(titleInput: string) {
    useEffect(() => {
        document.title=titleInput
    },[titleInput]);
}

function useWindowWidth() {
    const [width, setWidth] = useState(window.innerWidth);


    const handleResize = () => {
        setWidth(window.innerWidth)
    }

    useEffect(() => {
        window.addEventListener('resize', handleResize);
        return () => {
            window.removeEventListener('resize', handleResize)
        }
    }, [width])

    return width;
}