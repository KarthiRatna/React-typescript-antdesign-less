import React from 'react';
import styles from './ButtonUtility.module.less';
import { Button } from 'antd';

interface props {
    button_text: string;
    onClick: any
}

const ButtonUtility = ({ button_text, onClick }: props) => {
    return (
        <Button type="primary" className={styles["ant-btn-primary"]} onClick={onClick}>{button_text}</Button>
    )
}

export default ButtonUtility
